-- database/schema.sql
CREATE TABLE assets (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    type VARCHAR(50),
    base VARCHAR(100),
    quantity INT
);

CREATE TABLE purchases (
    id SERIAL PRIMARY KEY,
    asset_id INT,
    quantity INT,
    date TIMESTAMP
);

CREATE TABLE transfers (
    id SERIAL PRIMARY KEY,
    asset_id INT,
    from_base VARCHAR(100),
    to_base VARCHAR(100),
    quantity INT,
    date TIMESTAMP
);
