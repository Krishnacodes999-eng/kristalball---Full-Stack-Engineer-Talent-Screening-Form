// backend/server.js
const express = require('express');
const app = express();
app.use(express.json());

let purchases = [];
let transfers = [];

app.get('/', (req, res) => {
    res.send('Military Asset Management API Running');
});

app.post('/purchase', (req, res) => {
    purchases.push(req.body);
    res.json({ message: 'Purchase recorded' });
});

app.get('/purchases', (req, res) => {
    res.json(purchases);
});

app.post('/transfer', (req, res) => {
    transfers.push(req.body);
    res.json({ message: 'Transfer recorded' });
});

app.get('/transfers', (req, res) => {
    res.json(transfers);
});

app.listen(5000, () => console.log('Server running on port 5000'));
